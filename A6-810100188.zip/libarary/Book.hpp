#ifndef __Book_HH
#define __Book_HH
#include <vector>
#include <string>
#include <iostream>
#include "Document.hpp"
using namespace std;

class Book:public Document
{
public:
    Book(string book_title, int copies);
    virtual int calculate_debth(int day);
    virtual void extend(int day_now);
     virtual void set_time(int day);

};








#endif
