#include"Magzine.hpp"
using namespace std;
int const PUBLISH_YEAR=1390;
int const BORROWED_DAY=2;
int const FIRST_BOUNTY=2000;
int const SECOND_BOUNTY=3000;


string const MAG_EROR="You can’t renew magazines";
Magzine::Magzine(string magazine_title, int _year, int _number, int copies):Document(magazine_title,copies)
{
    year=_year;
    number=_number;
  
}

void Magzine::extend(int day_now){
    cout<<MAG_EROR<<endl;
    exit(0);
}

int  Magzine::calculate_debth(int day){
    int delay=day-time_should_returnd;
    int debth=0;
    if (delay<0)
        {
            delay=0;
            return debth;

        }
        
    if (year>=PUBLISH_YEAR)
    {
        debth=3000*delay;
        return debth;

      
    }
    else{
        debth=2000*delay;
       return debth;

    }

    return debth;
    
    
}

void Magzine::set_time(int day){
    time_borrowed=day;
    time_should_returnd=time_borrowed+BORROWED_DAY;
}