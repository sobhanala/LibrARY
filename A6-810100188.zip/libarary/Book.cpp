#include"Book.hpp"
using namespace std;
string const RENEW_ERROR="You can’t extend and borrow a document on the same day";
string const RENEW_ALOT="Maximum number of allowed borrows exceeded";
int const FIRST_DELAY_LIM=8;
int const SECOND_DELAY_LIM=21;
int const BORROWED_DAY=10;
int const FIRST_BOUNTY=2000;
int const SECOND_BOUNTY=3000;
int const THIRD_BOUNTY=5000;




Book::Book(string Book_title, int copies):Document(Book_title,copies){

}

void Book::extend(int day_now){
    
    if (time_borrowed-day_now==0)
    {
        cout<<RENEW_ERROR<<endl;
        exit(0);
    }
    if (extend_time>=2)
    {
        cout<<RENEW_ALOT<<endl;
        exit(0);
    }
    
    time_should_returnd=time_should_returnd+BORROWED_DAY;
    extend_time++;
}

int Book::calculate_debth(int day){
     int delay=day-time_should_returnd;
   
     int debth=0;
    if (delay<0)
        {
            delay=0;
            return debth;
        }
    if (delay<FIRST_DELAY_LIM )
    {
        debth=delay*FIRST_BOUNTY;
        return debth;
    }
    
    if (delay<=SECOND_DELAY_LIM and delay>FIRST_DELAY_LIM-1)
    {
       debth=7*FIRST_BOUNTY+(delay-(FIRST_DELAY_LIM-1))*SECOND_BOUNTY;
       return debth;
    }
    else{
        debth=(delay-SECOND_DELAY_LIM)*THIRD_BOUNTY+(SECOND_DELAY_LIM-FIRST_DELAY_LIM-1)*SECOND_BOUNTY+(FIRST_DELAY_LIM-1)*FIRST_BOUNTY;
        return debth;
    }
    
    

}

void Book::set_time(int day){
    time_borrowed=day;
    time_should_returnd=time_borrowed+BORROWED_DAY;
}