#ifndef __Refrence_HH
#define __Refrence_HH
#include <vector>
#include <string>
#include<iostream>
#include "Document.hpp"
using namespace std;

class Refrence:public Document
{
public:
    Refrence(string Refrence_title, int copies);
    virtual int calculate_debth(int day);
    virtual void extend(int day_now);
   virtual void set_time(int day);

};




#endif