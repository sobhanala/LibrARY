#include "Libarary.hpp"

string const USERNAME_EROR="Name already exists";
string const EMPTY_FIELD_EROR ="Empty field";
string const SAME_DOCUMENT="A document with the specified name already exists";
string const MAG_NUMBER="Invalid number";
string const MAG_DATE="Invalid year";
string const INVALID_DAY="Invalid day";
string const NOT_EXIST="This document does not exist";
string const MAX_BOOK="Maximum number of allowed borrows exceeded";
string const BORROWED_BEFOR="You borrowed this document already";
using namespace std;


void Library::same_name_doc(string title){
     for (int i = 0; i < docs.size(); i++)
    {
        if(docs[i]->book_exsist(title)==true){
            cout<<SAME_DOCUMENT<<endl;
            exit(0);
        }
    }
}

void Library::same_nam_user(string username){
    for (int i = 0; i < users.size(); i++)
    {
        if(users[i]->has_same_name(username)==true){
            cout<<USERNAME_EROR<<endl;
            exit(0);
        }
    }
    
}

void Library::add_student_member(string student_id,string user_name){
    same_nam_user(user_name);
    if (student_id=="")
    {
        cout<<EMPTY_FIELD_EROR<<endl;
    }
    Student * temp=new Student(student_id,user_name);
    users.push_back(temp);
}

void Library::add_prof_member(string user_name){
    same_nam_user(user_name);
    Professor * temp=new Professor(user_name);
    users.push_back(temp);

}

void Library::time_pass(int day){
    if (day<=0)
    {
        cout<<INVALID_DAY<< endl;
        exit(0);
    }

    witch_day=witch_day+day;
}

void Library::add_book(string book_name,int copys){
    same_name_doc(book_name);
    Book * temp=new Book (book_name,copys);
    docs.push_back(temp);
    for (int i = 0; i < copys; i++)
    {
        Book * copy_temp=new Book (book_name,copys);
        docs_usble.push_back(copy_temp);
    }
    
}

void Library::add_reference(string ref_name,int number){
    same_name_doc(ref_name);
    Refrence * temp=new Refrence (ref_name,number);
    docs.push_back(temp);
    for ( int i = 0; i < number; i++)
    {
        Refrence * copy_temp=new Refrence (ref_name,number);
        docs_usble.push_back(copy_temp);
    }
    

}

void Library::add_magazine(string magazine_title, int year, int number, int copies){
   same_name_doc(magazine_title);
   if (number<=0)
   {
       cout<<MAG_NUMBER<<endl;
       exit(0);
   }
   if(year<=0){
       cout<<MAG_DATE<<endl;
       exit(0);
   }
   
    Magzine* temp=new Magzine (magazine_title,year,number,copies);
    docs.push_back(temp);
    for ( int i = 0; i < number; i++)
    {
        Magzine * copy_temp=new Magzine (magazine_title,year,number,copies);
        docs_usble.push_back(copy_temp);
    }
     
}

Person *  Library::member_exist(string name){
    for (int i = 0; i < users.size(); i++)
    {
        if(users[i]->has_same_name(name)){
            return users[i];
        }   
    }
    return NULL;
}

int  Library::doc_exist(string document_title){
     for (int i = 0; i < docs_usble.size(); i++)
    {
        if(docs_usble[i]->book_exsist(document_title)){
            
            return i;
        }
    }

    return -1;

}

void Library::borrow(string member_name,string document_title){

    Person * temp=member_exist(member_name);    
    int index =doc_exist(document_title);

    if(index==-1){
        cout<<NOT_EXIST<<endl;
        exit(0);
    }
    
    if(temp->how_many_boroowed()){
        cout<<MAX_BOOK<<endl;
        exit(0);        
    }
    
    if(temp->borrowed_befor(docs_usble[index])){
        cout<<BORROWED_BEFOR<<endl;
    }
    docs_usble[index]->set_time(witch_day);
    temp->add_to_lib(docs_usble[index],document_title);
    docs_usble.erase(docs_usble.begin()+index);
}

vector<string> Library::available_titles(){
    vector <string> titels;
    
    
   for (int i = 0; i < docs_usble.size(); i++)
   {

    titels.push_back(docs_usble[i]->get_name());
       
   }
   sort( titels.begin(), titels.end() );
    titels.erase(unique( titels.begin(), titels.end() ), titels.end() );
   
    return titels;
    
}

void Library::extend(string member_name,string doc_title){
    Person * temp=member_exist(member_name);  
    temp->extend(doc_title,witch_day);
}


int Library::get_total_penalty(string member_name){
    return member_exist(member_name)->calculate_penalty(witch_day);

}


void Library::print(){
    for (int i = 0; i < docs_usble.size(); i++)
    {
       cout<<docs_usble[i]->get_name()<<endl;
    }
    
}


void Library::return_document(string member_name, string document_title){
    auto returnd_doc=member_exist(member_name)->return_doc(document_title);
    docs_usble.push_back(returnd_doc);
}