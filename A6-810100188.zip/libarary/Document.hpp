#ifndef __DOCUMENT__HH
#define __DOCUMENT__HH
#include <vector>
#include <string>
using namespace std;

class Document{
public:
    Document(string book_title, int copies);
    bool book_exsist(string title);
    vector<int> get_remains();
    string get_name();
    virtual int calculate_debth(int day)=0;
    virtual void extend(int day_now)=0;
    virtual void set_time(int day)=0;    
    protected:
    string name;
    int time_borrowed;
    int time_should_returnd;
    int copy_remains;
    int extend_time=0;

};


#endif