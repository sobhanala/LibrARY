#ifndef _Prof_person_HH
#define _Prof_person_HH
#include <vector>
#include <string>
#include"person.hpp"
using namespace std;

class Professor:public Person
{
public:
    Professor(string user_name);
    // void calculate_penalty();
    // void extend();
    virtual bool how_many_boroowed();

};





#endif