#ifndef __LIBRARY_HH__
#define __LIBRARY_HH__
#include <vector>
#include <string>
#include <algorithm>
#include <iostream>
#include"person.hpp"
#include"Person_prof.hpp"
#include"Person_student.hpp"
#include"Document.hpp"
#include"Magzine.hpp"
#include"Book.hpp"
#include"Refrence.hpp"

using namespace std;

class Library {
public:
	void add_student_member(string student_id, string student_name);
	void add_prof_member(string prof_name);
	void add_book(string book_title, int copies);
	void add_magazine(string magazine_title, int year, int number, int copies);
	void add_reference(string reference_title, int copies);
	void borrow(string member_name, string document_title);
	void extend(string member_name, string document_title);
	void return_document(string member_name, string document_title);
	int get_total_penalty(string member_name);
	vector<string> available_titles();
	void time_pass(int days);
	Person * member_exist(string member_name);
	int doc_exist(string document_title);
	void same_nam_user(string username);
	void same_name_doc(string title);
	void print();
private:
vector <Person *> users;
vector <Document *> docs;
vector <Document *> docs_usble;

int witch_day=0;

};

#endif