#include "Document.hpp"
using namespace std;


Document::Document(string _book_title, int _copies){

    name=_book_title;
    copy_remains=_copies;
}
bool Document::book_exsist(string title){
    if(name==title){
        return true;
    }
    return false;
}

vector<int> Document::get_remains(){
    vector <int> temp;
    temp.push_back(time_borrowed);
    temp.push_back(copy_remains);
    return temp;
}

string  Document::get_name(){
    return name;

}

