#include <vector>
#include <string>
#include"person.hpp"
#include"Person_prof.hpp"
#include"Person_student.hpp"
#include"Document.hpp"
#include"Magzine.hpp"
#include"Book.hpp"
#include"Refrence.hpp"
#include"Libarary.hpp"

int main(){
	Library ut_lib;
	ut_lib.time_pass(10);//day=10
	ut_lib.add_student_member("0", "std1");

	ut_lib.add_book("book1", 3);
	ut_lib.add_book("book2", 3);

	ut_lib.borrow("std1","book1");//time borrow=10 time return=20
	ut_lib.time_pass(5);//

	ut_lib.extend("std1", "book1");
	ut_lib.borrow("std1", "book2");//15  
	ut_lib.time_pass(20);//35  

	cout << ut_lib.get_total_penalty("std1") << '\n';//35
	ut_lib.return_document("std1", "book1");
	ut_lib.return_document("std1", "book2");
  	return 0;

  	return 0;

}