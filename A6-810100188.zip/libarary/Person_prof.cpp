#include "Person_prof.hpp"
using namespace std;


Professor::Professor(string _user_name):Person(_user_name){
    
}


bool Professor::how_many_boroowed(){
    if (books.size()>=2)
    {
        return true;
    }
    return false;
}