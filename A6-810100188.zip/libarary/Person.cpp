#include "person.hpp"
using namespace std;
string const NOT_BORROWED="You have not borrowed this document";
Person::Person(string _user_name){
    user_name=_user_name;
}

bool Person::has_same_name(string name){
    if(user_name==name){
        return true;
    }
        return false;
}

void Person::add_to_lib(Document * doc,string title){
    for (int i = 0; i < books.size(); i++)
    {
        if(books[i]->book_exsist(title)){
            break;
        }
    }
    
    books.push_back(doc);
}

bool Person::borrowed_befor(Document * new_book){
    for (int  i = 0; i < books.size(); i++)
    {
        if (books[i]==new_book)
        {
            return true;
        }
        
    }
    return false;
}

int Person::find_doc(string name){

    for (int i = 0; i < books.size(); i++)
    {
        if (name==books[i]->get_name())
        {
           return i;
        }
        
    }
    return -1;
}

void Person::extend(string doc_title,int day_now){
    if(find_doc(doc_title)!=-1){
        books[find_doc(doc_title)]->extend(day_now);
    }
    else{
        cout<<NOT_BORROWED<<endl;
        exit(0);
    }
}

int Person::calculate_penalty(int day){
    int debth=0;
    for (int i = 0; i < books.size(); i++)
    {
        debth=debth+books[i]->calculate_debth(day);
    }
    return debth;
}


Document * Person::return_doc(string document_name){
        if(find_doc(document_name)!=-1){
        auto temp=books[find_doc(document_name)];
        books.erase(books.begin()+find_doc(document_name));
        return temp;

    }
    else{
        cout<<NOT_BORROWED<<endl;
        exit(0);
    }
}
