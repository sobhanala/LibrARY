#ifndef __PERSONSTUDENT__HH
#define __PERSONSTUDENT__HH
#include <vector>
#include <string>
#include"person.hpp"

using namespace std;

class Student:public Person
{
public:
    Student(string stude_id,string user_name);
    //void calculate_penalty();
    // void extend();
    virtual bool how_many_boroowed();

protected:
string student_id;

};





#endif