#ifndef __PERSON__HH
#define __PERSON__HH
#include <vector>
#include <string>
#include <iostream>
#include"Document.hpp"
using namespace std;


class Person
{
public:
    Person(string user_name);
    int calculate_penalty(int day);
    void extend(string doc_title,int day_now);
    bool has_same_name(string name);
    void add_to_lib(Document * doc,string titele);
    virtual bool how_many_boroowed()=0;
    bool borrowed_befor(Document * doc);
    int  find_doc(string title);
    Document * return_doc(string document_name);

protected:
    string user_name;
    int total_debth;
    vector <Document *> books;
};





#endif