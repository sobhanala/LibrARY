#include "Person_student.hpp"
using namespace std;


Student::Student(string s_id,string _user_name):Person(_user_name){
    student_id=s_id;
}
bool Student::how_many_boroowed(){
    if (books.size()>=2)
    {
        return true;
    }
    return false;
}