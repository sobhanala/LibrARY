#ifndef __MAGZINE_HH
#define __MAGZINE_HH
#include <vector>
#include <string>
#include<iostream>
#include "Document.hpp"
using namespace std;

class Magzine:public Document
{
public:
    Magzine(string magazine_title, int year, int number, int copies);
    virtual int calculate_debth(int day_now);
    virtual void extend(int day_now);
    virtual void set_time(int day);

    

protected:
    int year;
    int number;


};





#endif
